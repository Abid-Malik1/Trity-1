#!/bin/sh

cd /opt/trity
python /opt/trity/trity.py
